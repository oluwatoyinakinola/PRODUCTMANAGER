import pygame
from pygame.sprite import AbstractGroup

WHITE = (255,255,255)
BLACK = (0,0,0)
FONT_TYPE = 'freesansbold.ttf'
FONT  = pygame.font.Font


class TextEntry(pygame.sprite.Sprite):
    def __init__(self, width, height, fontsize,x,y) -> None:
        self.id = None
        self.width = width
        self.height = height
        self.fontsize = fontsize
        self.font = FONT(FONT_TYPE,fontsize)

        self.image = pygame.surface.Surface((self.width, self.height))
        self.rect = self.image.get_rect()
        self.rect.topleft = (x,y)
        self.image.fill(WHITE)

        self.text = ''
        self.active = False
        
    def key_listener(self):
        keys = pygame.key.get_pressed()
            
    def update(self,event):
        self.image.fill(WHITE)  
        if event.type == pygame.MOUSEBUTTONDOWN:
            if self.rect.collidepoint(event.pos):
                self.active = True
                
            else:
                self.active = False
        if event.type == pygame.KEYDOWN:
            if self.active:
                if event.key == pygame.K_RETURN:
                    txt = self.text
                    self.text = ''
                    return txt
                elif  event.key == pygame.K_BACKSPACE:
                    self.text = self.text[:-1]
                else:
                    self.text += event.unicode                 
        #create a text object 
        text = self.font.render(self.text, True, BLACK) 
        text_rect = text.get_rect()

        self.image.blit(text,(10,(self.rect.h-text_rect.h)/2))
        border = pygame.Rect(0,0, self.width,self.height)
        pygame.draw.rect(self.image, BLACK, border,2)

class Button(pygame.sprite.Sprite):
    def __init__(self, width, height,text,color,text_color,fontsize,x,y) -> None:
        super().__init__()
        self.id = None
        self.image = pygame.surface.Surface((width,height)) 
        self.image.fill(color)      
        self.rect = self.image.get_rect() 
        self.rect.topleft = x,y
        self.fontsize = fontsize
        self.font = FONT(FONT_TYPE,fontsize)

        self.text = text
        self.color = color
        self.text_color = text_color
    def update(self,event):
        self.image.fill(self.color)    
        text = self.font.render(self.text, True, self.text_color) 
        text_rect = text.get_rect()

        self.image.blit(text,(10,(self.rect.h-text_rect.h)/2))
        if event.type == pygame.MOUSEBUTTONDOWN:
            if self.rect.collidepoint(event.pos):
                    return True                
            
class Cell(pygame.sprite.Sprite):
    def __init__(self, text,color,text_color,fontsize,x,y) -> None:
        super().__init__()
        self.id = None
        self.image = pygame.surface.Surface((300,60)) 
        self.image.fill(color)      
        self.rect = self.image.get_rect() 
        self.rect.topleft = x,y
        self.fontsize = fontsize
        self.font = FONT(FONT_TYPE,fontsize)

        self.text = text
        self.color = color
        self.text_color = text_color
    def update(self,event):
        self.image.fill(self.color)    
        
        text = self.font.render(self.text, True, self.text_color) 
        text_rect = text.get_rect()

        self.image.blit(text,(10,(self.rect.h-text_rect.h)/2))
        if event.type == pygame.MOUSEBUTTONDOWN:
            if self.rect.collidepoint(event.pos):
                    return True         
class TxStrip(pygame.sprite.Sprite):
    def __init__(self, width, height,text,color,text_color,fontsize,x,y) -> None:
        super().__init__()
        self.id = None
        self.image = pygame.surface.Surface((width,height)) 
        self.image.fill(color)      
        self.rect = self.image.get_rect() 
        self.rect.topleft = x,y
        self.fontsize = fontsize
        self.font = FONT(FONT_TYPE,fontsize)

        self.text = text
        self.color = color
        self.text_color = text_color
    def update(self,event):
        self.image.fill(self.color)    
        text = self.font.render(self.text, True, self.text_color) 
        text_rect = text.get_rect()

        self.image.blit(text,(10,(self.rect.h-text_rect.h)/2))
        '''
        if event.type == pygame.MOUSEBUTTONDOWN:
            if self.rect.collidepoint(event.pos):
                    return True'''            
class RadioButton(pygame.sprite.Sprite)  :
    def __init__(self,x,y,tag,width,hieght,color,bordercolor):
        super().__init__()  
        self.image = pygame.surface.Surface((width,hieght))
        self.rect = self.image.get_rect()
        self.rect.topleft = x,y
        self.tag = tag
        self.color = color
        self.bordercolor = bordercolor
        self.ticked = False
        self.width,self.hieght = width, hieght
    def update(self,event) -> None:
        if self.ticked:
            self.image.fill(self.color)
        else:
            self.image.fill(WHITE)
        border = pygame.Rect(0,0, self.width,self.hieght)
        pygame.draw.rect(self.image, self.bordercolor, border,2)
        if event.type == pygame.MOUSEBUTTONDOWN:
            if self.rect.collidepoint(event.pos):
                    if self.ticked:
                        self.ticked = False
                    else:
                        self.ticked = True    
                    return True                              