import pygame
import zMvc
pygame.init()
window_size = [1000,600]
screen = pygame.display.set_mode(window_size)

Widgets = []

import front_forms
import dashboard
import widgets
import student
import student_view
import view_chart

def delete_widgets(id):
    global Widgets
    new = []
    for widget in Widgets:
        if widget.id == id:
           pass
        else:
            new.append(widget)  
    Widgets = []
    for i in new:
        Widgets.append(i)    

DATA = []

def draw_widgets():
    for widget in Widgets:
        screen.blit(widget.image,widget.rect.topleft)
def update_attendance(attendance_vals,server):
    global DATA
    for student in DATA:
        attendance = attendance_vals[student.first_name +" "+student.last_name]
        student.attendance_record[attendance[0]] = attendance[1]
        if attendance[1] == 'present':
            server.PUT([student.attendance_id, attendance[0], 1],attendance = True)
        else: 
            server.PUT([student.attendance_id, attendance[0], 0],attendance = True)   


def add_widgets(widgets):
    for widget in widgets:
        Widgets.append(widget) 
def add_widget(widget):
    Widgets.append(widget)        
def main():
    global student
    server = zMvc.Server('main_db.db')
    DATA = server.GET()
    for i in DATA:
        print(i.attendance_record)
    add_button = widgets.Button(100,50,"add",(0,120,255),widgets.WHITE,20, 60,60)
    class_button = widgets.Button(200,50,"view classroom",(0,120,255),widgets.WHITE,20, 200,60)
    attendanceform = widgets.Button(200,50,"mark attendance",(0,120,255),widgets.WHITE,20, 440,60)
    add_widget(add_button)
    add_widget(class_button)
    add_widget(attendanceform)
    #form = dashboard.Dashboard(data,400,100)#front_forms.Form(400,100)
    #add_widgets(form.widgets)
    view = None
    running = True
    clock = pygame.time.Clock()
    while running:
        '''
        if view:
            print("view id",view.id)
        for wid in Widgets:
            print(wid.id,'\n')
        print('length of widgets',len(Widgets))  '''  
        
        if_add = None
        if_viewclass = None
        view_return = None
        attendance_mark = None
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                server.close()
                running = False 
            if view :
                view_return = view.update(event)  
            if_add = add_button.update(event) 
            if_viewclass = class_button.update(event)
            attendance_mark = attendanceform.update(event)
        screen.fill(widgets.WHITE) 
        if if_add:
            if view: 
                if view.id != 1:
                    delete_widgets(view.id)
                    view = None                    
                    view = front_forms.Form(200,150,1)              
                    add_widgets(view.widgets)
            else:    
                view = front_forms.Form(200,150,1)              
                add_widgets(view.widgets)    
        if if_viewclass:
            if view: 
                if view.id != 2:
                    delete_widgets(view.id)
                    view = None
                    view = dashboard.Dashboard(DATA,200,150,2)              
                    add_widgets(view.widgets)
            else:    
                view = dashboard.Dashboard(DATA,200,150,2)               
                add_widgets(view.widgets)    
        if view_return and view.id == 2:
            delete_widgets(view.id)
            view = student_view.StudentView(200,150,view_return[1],3)
            add_widgets(view.widgets)
        if attendance_mark:
            if view: 
                if view.id != 3:
                    delete_widgets(view.id)
                    view = view_chart.AttendanceForm(0,150,DATA,3)
                    add_widgets(view.widgets)
            
        if view_return == "submit":
            if view.id == 1:

                data = view.getData()
                student_obj = student.Student()
                print(data[0],data[1])
                student_obj.first_name,student_obj.last_name = data[0],data[1]
                DATA.append(student_obj)
                server.POST(student_obj)
                delete_widgets(view.id)
                #view.delete_kill_widgets()
                view = None
            elif view.id == 3:
                data = view.tick_box_vals
                for student in DATA:
                    attendance = data[student.first_name +" "+student.last_name]
                    student.attendance_record[attendance[0]] = attendance[1]
                    if attendance[1] == 'present':
                        server.PUT([student.attendance_id, attendance[0], 1],attendance = True)
                    else: 
                        server.PUT([student.attendance_id, attendance[0], 0],attendance = True)   
                view = None

      

            



        draw_widgets()        
        pygame.display.flip()    
        clock.tick(30)               

if __name__ == '__main__':
    main()  