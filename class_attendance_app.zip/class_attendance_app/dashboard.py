import student
import widgets

class Dashboard():
    def __init__(self,students_data,x,y,id):
        #student data is a dictionary
        self.id = id
        self.student_data = students_data
        self.x,self.y = x,y
        self.widgets = []
        self.create_dashboard()
    def create_dashboard(self):
        y = self.y + 60
        namestrip = widgets.TxStrip(300,60,"Name",(0,24,51),widgets.WHITE,20,self.x,self.y)
        pointstrip = widgets.TxStrip(200,60,"Points",(0,24,51),widgets.WHITE,20,self.x+300,self.y)
        self.widgets.append(namestrip)
        self.widgets.append(pointstrip)
        for student in self.student_data:
            cell1 = widgets.Cell(student.first_name +" "+student.last_name,widgets.WHITE,widgets.BLACK,20,self.x,y) 
            cell2 = widgets.Cell(str(student.questions_anwered),widgets.WHITE,widgets.BLACK,20,self.x+300,y) 
            self.widgets.append(cell1)
            self.widgets.append(cell2)
            y += 60
        for widget in self.widgets:
            widget.id = self.id    
    def delete_kill_widgets(self):
        for widget in self.widgets:
            del widget            
    def update(self,event):
        for widget in self.widgets:
            response = widget.update(event)
            if response:
                for student in self.student_data:
                    if student.first_name +" "+student.last_name == widget.text:
                        return response, student
            