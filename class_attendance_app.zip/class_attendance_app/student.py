class Student():
    def __init__(self):
        self.first_name = str
        self.last_name = str
        self.questions_anwered = 0
        self.attendance_record = {}
        self.attendance_id = int