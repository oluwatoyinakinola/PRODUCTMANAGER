import student
import widgets


class Form():
    def __init__(self,x,y,id):
        self.id = id
        self.first_name_field = str
        self.last_name_field  = str
        self.widgets = []
        self.coord = [x,y]
        self.create_form()
        
    def create_form(self):
        firstnametext = widgets.TxStrip(300,30,"First name",(255,255,255),widgets.BLACK,20,self.coord[0],self.coord[1])
        lastnametext = widgets.TxStrip(300,30,"Last name",(255,255,255),widgets.BLACK,20,self.coord[0],self.coord[1]+170)
        self.first_name = widgets.TextEntry(200,40,20,self.coord[0],self.coord[1]+80)
        self.last_name  = widgets.TextEntry(200,40,20,self.coord[0],self.coord[1]+220)
        self.button = widgets.Button(100,50,"submit",(0,120,255),widgets.WHITE,20, self.coord[0],self.coord[1]+290)
        
        self.widgets.append(firstnametext)      
        self.widgets.append(self.first_name)
        self.widgets.append(self.last_name)
        self.widgets.append(lastnametext)          
        
        self.widgets.append(self.button)
        for widget in self.widgets:
            widget.id = self.id
           

    def getData(self):
        return self.first_name_field, self.last_name_field    
    def delete_kill_widgets(self):
        for widget in self.widgets:
            del widget
    def update(self,event):
        for widget in self.widgets[0:4]:
            widget.update(event)
        self.first_name_field = self.first_name.text 
        self.last_name_field = self.last_name.text  
        clicked = self.widgets[-1].update(event)
        if clicked:
            if self.first_name_field and self.last_name_field != '':
                return "submit"

if __name__ == '__main__':
    form = Form()
    textbox = widgets.TextEntry(20,30)
    print(form.first_name_field)        