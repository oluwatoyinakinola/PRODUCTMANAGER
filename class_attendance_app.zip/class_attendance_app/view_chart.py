import widgets

class AttendanceForm():
        def __init__(self,x,y,data,id):
            self.id = id
            self.date = str
            #self.last_name_field  = str
            self.widgets = []
            self.tick_boxes = []
            self.tick_box_vals = {}
            self.coord = [x,y]
            self.x,self.y = x,y
            self.students_data = data  
            self.create_form()              

        def create_form(self):
            datetext = widgets.TxStrip(300,30,"Date",(255,255,255),widgets.BLACK,20,self.coord[0],self.coord[1])
            #lastnametext = widgets.TxStrip(300,30,"Last name",(255,255,255),widgets.BLACK,20,self.coord[0],self.coord[1]+170)
            self.date_entry = widgets.TextEntry(200,40,20,self.coord[0],self.coord[1]+80)
            #self.last_name  = widgets.TextEntry(200,40,20,self.coord[0],self.coord[1]+220)
            self.button = widgets.Button(100,50,"submit",(0,120,255),widgets.WHITE,20, self.coord[0],self.coord[1]+290)

            y = self.y + 60
            namestrip = widgets.TxStrip(300,60,"Name",(0,24,51),widgets.WHITE,20,self.x+400,self.y)
            pointstrip = widgets.TxStrip(200,60,"attendance",(0,24,51),widgets.WHITE,20,self.x+700,self.y)
            self.widgets.append(namestrip)
            self.widgets.append(pointstrip)
            for student in self.students_data:
                cell1 = widgets.Cell(student.first_name +" "+student.last_name,widgets.WHITE,widgets.BLACK,20,self.x+400,y) 
                cell2 = widgets.RadioButton(self.x+700,y,student.first_name +" "+student.last_name,40,40,(10,255,50),widgets.BLACK) 
                self.widgets.append(cell1)
                self.widgets.append(cell2)
                self.tick_boxes.append(cell2)
                self.tick_box_vals[student.first_name +" "+student.last_name] = {}
                y += 60
            self.widgets.append(datetext)      
            self.widgets.append(self.date_entry)
            #self.widgets.append(self.last_name)
            #self.widgets.append(lastnametext)          
            
            self.widgets.append(self.button)
            for widget in self.widgets:
                widget.id = self.id  
        def update(self,event):
            for widget in self.widgets:
                response = widget.update(event)
            self.date = self.date_entry.text    
            for tick in self.tick_boxes:
                 if tick.ticked:
                      self.tick_box_vals[tick.tag] = [self.date,"present"]
                 else:
                      self.tick_box_vals[tick.tag] = [self.date,"absent"]
                      
            clicked = self.button.update(event)
            if clicked:
                #print(self.tick_box_vals)
                #if self.first_name_field and self.last_name_field != '':
                return "submit"
                          
                                  