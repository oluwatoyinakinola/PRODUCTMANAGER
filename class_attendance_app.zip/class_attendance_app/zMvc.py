from student import Student
import sqlite3
def set_up_db(name):
    dbConnection = sqlite3.connect(name) 
    cursor = dbConnection.cursor()
    cursor.execute("""CREATE TABLE STUDENTS(first_name VARCHAR(255), last_name VARCHAR(255), questions_answered int, attendance_record int)""")
    cursor.execute("""CREATE TABLE ATTENDANCE(id int, date VARCHAR(255), status BOOLEAN)""")
    #listOfTables = cursor.execute(f"""SELECT tableName FROM sqlite_master WHERE type='table' 
    #                              AND tableName={name};""").fetchall()
    #if listOfTables == []:
     #   print('table does not exist')
    #else:
     #   print('table exists')     
    dbConnection.commit()
    dbConnection.close()    
class Server:
    def __init__(self, db):
        self.dbConnection = sqlite3.connect(db)
        self.cursor = self.dbConnection.cursor()

    def GET(self,obj_name=None):
        if obj_name:
            self.cursor = self.dbConnection.execute(f"SELECT * from Students WHERE first_name == {obj_name}")
            student_obj = None
            for student in self.cursor:
                student_obj = Student()
                student_obj.first_name = student[0]
                student_obj.last_name = student[1]
                student_obj.questions_anwered = student[2]
                student_obj.attendance_id = student[3]            
            if student_obj:
                return student_obj
            else:
                return None
        else:
            self.cursor = self.dbConnection.execute("SELECT * from Students")
            objects = []

            for student in self.cursor:
                student_obj = Student()
                student_obj.first_name = student[0]
                student_obj.last_name = student[1]
                student_obj.questions_anwered = student[2]
                student_obj.attendance_id = student[3]
                objects.append(student_obj)  
            for student in objects:
                attendance = {}
                self.cursor = self.dbConnection.execute(f"SELECT * from ATTENDANCE WHERE id == {student.attendance_id}")
                for attendance_val in self.cursor:
                    if attendance_val[2]:
                        attendance[attendance_val[1]] = "present"
                    else:
                        attendance[attendance_val[1]] = "absent"
                student.attendance_record = attendance
            return objects     
  

    def POST(self,obj):
        attendance_id = None
        self.cursor = self.dbConnection.execute("SELECT attendance_record from Students")
        attendance_id = max(self.cursor)[0]
        self.cursor = self.dbConnection.execute(f"INSERT INTO Students VALUES ('{obj.first_name}','{obj.last_name}', 0,{attendance_id + 1})")
        self.dbConnection.commit()
    def PUT(self,data,attendance=False):
        if attendance:       
            self.dbConnection.execute(f"INSERT INTO ATTENDANCE VALUES ({data[0]}, '{data[1]}', {data[2]}) ")
            self.dbConnection.commit()
            
    def DELETE(self,obj):
        pass
    def close(self):
        self.dbConnection.commit()
        self.dbConnection.close()
if __name__ == '__main__':
    server = Server('main_db.db')
    server.GET()
    server.POST('sddd')
    #set_up_db('main_db.db')