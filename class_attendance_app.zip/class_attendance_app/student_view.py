import student
import widgets


class StudentView():
    def __init__(self,x,y,student_data,id):
        self.id = id
        self.x,self.y = x,y
        self.widgets = []
        self.coord = [x,y]
        self.data = student_data
        
        self.create_view()
    def delete_kill_widgets(self):
        for widget in self.widgets:
            del widget        
    def create_view(self):
        y = self.y + 60
        namestrip = widgets.TxStrip(300,60,self.data.first_name +" "+self.data.last_name,(0,24,51),widgets.WHITE,20,self.x,self.y)
        attendancestrip = widgets.TxStrip(200,60,"Attendance",(0,24,51),widgets.WHITE,20,self.x+300,self.y)
        self.widgets.append(namestrip)
        self.widgets.append(attendancestrip)
        for  row in self.data.attendance_record:
            cell1 = widgets.Cell(row,widgets.WHITE,widgets.BLACK,20,self.x,y)
            cell2 = widgets.Cell(self.data.attendance_record[row],widgets.WHITE,widgets.BLACK,20,self.x+300,y)  
            self.widgets.append(cell1)
            self.widgets.append(cell2)
            y += 60   
        for widget in self.widgets:
            widget.id = self.id         
    def update(self,event):
        for widget in self.widgets:
            response = widget.update(event)
        clicked = self.widgets[-1].update(event)
        if clicked:
            if self.first_name_field and self.last_name_field != '':
                return "submit"            
